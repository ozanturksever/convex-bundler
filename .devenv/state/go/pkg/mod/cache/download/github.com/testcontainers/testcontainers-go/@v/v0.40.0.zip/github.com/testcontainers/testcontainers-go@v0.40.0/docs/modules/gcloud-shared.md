#### WithProjectID

- Since <a href="https://github.com/testcontainers/testcontainers-go/releases/tag/v0.37.0"><span class="tc-version">:material-tag: v0.37.0</span></a>

The `WithProjectID` function sets the project ID for the Google Cloud container.
