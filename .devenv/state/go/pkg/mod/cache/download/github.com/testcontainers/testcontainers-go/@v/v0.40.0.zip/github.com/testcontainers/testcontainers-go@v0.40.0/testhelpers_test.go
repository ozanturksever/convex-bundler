package testcontainers_test

const (
	nginxAlpineImage = "nginx:alpine"
	nginxDefaultPort = "80/tcp"
)
