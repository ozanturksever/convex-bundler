# Azurite

Since <a href="https://github.com/testcontainers/testcontainers-go/releases/tag/v0.32.0"><span class="tc-version">:material-tag: v0.32.0</span></a>

!!!warning
    This module is deprecated and will be removed in the next major release of _Testcontainers for Go_. Please use [Azurite from the Azure module](../azure/#azurite) instead.
