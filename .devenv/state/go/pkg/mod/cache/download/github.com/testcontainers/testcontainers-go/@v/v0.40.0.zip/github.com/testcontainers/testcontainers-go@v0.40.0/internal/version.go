package internal

// Version is the next development version of the application
const Version = "0.40.0"
