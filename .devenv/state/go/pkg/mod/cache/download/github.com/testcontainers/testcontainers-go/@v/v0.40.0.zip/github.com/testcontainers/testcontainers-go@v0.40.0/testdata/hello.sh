#!/usr/bin/env bash
echo "hello world" > /data/hello.txt
echo "done"
