# Drone CI

Drone CI 0.8 is supported via the use of a general purpose Docker-in-Docker plugin.

Please see [testcontainers/dind-drone-plugin](https://github.com/testcontainers/dind-drone-plugin) for further details and usage instructions.

