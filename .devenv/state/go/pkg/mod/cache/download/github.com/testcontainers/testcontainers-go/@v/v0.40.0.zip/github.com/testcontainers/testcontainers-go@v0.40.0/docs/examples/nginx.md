# Nginx

<!--codeinclude-->
[Creating a Nginx container](../../examples/nginx/nginx.go)
<!--/codeinclude-->

<!--codeinclude-->
[Test for a Nginx container](../../examples/nginx/nginx_test.go)
<!--/codeinclude-->
